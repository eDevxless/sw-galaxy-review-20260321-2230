// State
const viewport = document.getElementById("mapViewport");
const stage = document.getElementById("mapStage");
const img = document.getElementById("mapImage");
const pinLayer = document.getElementById("pinLayer");
const infoPanel = document.getElementById("infoPanel");
const panelClose = document.getElementById("panelClose");
const searchInput = document.getElementById("searchInput");
const searchResults = document.getElementById("searchResults");

let state = { scale: 1, x: 0, y: 0, isDragging: false, startX: 0, startY: 0, activePin: null };

// Transform
function applyTransform() {
  stage.style.transform = `translate(${state.x}px,${state.y}px) scale(${state.scale})`;
}

function fitToViewport() {
  const vr = viewport.getBoundingClientRect();
  const s = Math.min(vr.width / img.naturalWidth, vr.height / img.naturalHeight, 1);
  state.scale = s;
  state.x = (vr.width - img.naturalWidth * s) / 2;
  state.y = (vr.height - img.naturalHeight * s) / 2;
  applyTransform();
}

function clamp(v, a, b) {
  return Math.min(b, Math.max(a, v));
}

function zoomAt(cx, cy, delta) {
  const vr = viewport.getBoundingClientRect();
  const prev = state.scale;
  const next = clamp(prev * delta, 0.2, 8);
  if (next === prev) return;

  const ox = cx - vr.left;
  const oy = cy - vr.top;
  state.x = ox - (ox - state.x) * (next / prev);
  state.y = oy - (oy - state.y) * (next / prev);
  state.scale = next;
  applyTransform();
}

// Pan
viewport.addEventListener("pointerdown", (e) => {
  state.isDragging = true;
  state.startX = e.clientX - state.x;
  state.startY = e.clientY - state.y;
  viewport.classList.add("dragging");
  viewport.setPointerCapture(e.pointerId);
});

viewport.addEventListener("pointermove", (e) => {
  if (!state.isDragging) return;
  state.x = e.clientX - state.startX;
  state.y = e.clientY - state.startY;
  applyTransform();
});

function stopDrag(e) {
  if (e && viewport.hasPointerCapture(e.pointerId)) viewport.releasePointerCapture(e.pointerId);
  state.isDragging = false;
  viewport.classList.remove("dragging");
}

viewport.addEventListener("pointerup", stopDrag);
viewport.addEventListener("pointercancel", stopDrag);

// Zoom
viewport.addEventListener(
  "wheel",
  (e) => {
    e.preventDefault();
    zoomAt(e.clientX, e.clientY, e.deltaY < 0 ? 1.12 : 0.9);
  },
  { passive: false }
);

viewport.addEventListener("dblclick", (e) => zoomAt(e.clientX, e.clientY, 1.5));

document.querySelector(".controls").addEventListener("click", (e) => {
  const btn = e.target.closest("button");
  if (!btn) return;

  const vr = viewport.getBoundingClientRect();
  const cx = vr.left + vr.width / 2;
  const cy = vr.top + vr.height / 2;

  if (btn.dataset.action === "zoom-in") zoomAt(cx, cy, 1.25);
  if (btn.dataset.action === "zoom-out") zoomAt(cx, cy, 0.8);
  if (btn.dataset.action === "reset") fitToViewport();
});

// Pins
function buildPins() {
  pinLayer.innerHTML = "";
  PLANETS.forEach((p) => {
    const pin = document.createElement("div");
    pin.className = "pin";
    pin.style.left = `${p.x * img.naturalWidth}px`;
    pin.style.top = `${p.y * img.naturalHeight}px`;
    pin.dataset.name = p.name;

    const dot = document.createElement("div");
    dot.className = "pin-dot";

    const label = document.createElement("div");
    label.className = "pin-label";
    label.textContent = p.name;

    pin.appendChild(dot);
    pin.appendChild(label);
    pin.addEventListener("click", (e) => {
      e.stopPropagation();
      selectPlanet(p, pin);
    });
    pinLayer.appendChild(pin);
  });
}

function selectPlanet(p, pinEl) {
  if (state.activePin) state.activePin.classList.remove("active");
  state.activePin = pinEl;
  pinEl.classList.add("active");

  document.getElementById("panelGrid").textContent = `Grid ${p.grid}`;
  document.getElementById("panelName").textContent = p.name;
  document.getElementById("panelGridCoord").textContent = p.grid;
  document.getElementById("panelRegion").textContent = p.region;
  document.getElementById("panelTerrain").textContent = `Terrain: ${p.terrain}`;
  document.getElementById("panelDesc").textContent = p.desc;
  infoPanel.classList.add("open");
}

panelClose.addEventListener("click", () => {
  infoPanel.classList.remove("open");
  if (state.activePin) {
    state.activePin.classList.remove("active");
    state.activePin = null;
  }
});

viewport.addEventListener("click", () => {
  infoPanel.classList.remove("open");
  if (state.activePin) {
    state.activePin.classList.remove("active");
    state.activePin = null;
  }
});

// Search
searchInput.addEventListener("input", () => {
  const q = searchInput.value.trim().toLowerCase();
  if (q.length < 1) {
    searchResults.classList.remove("open");
    searchResults.innerHTML = "";
    return;
  }

  const hits = PLANETS.filter((p) => p.name.toLowerCase().includes(q)).slice(0, 8);
  searchResults.innerHTML = hits
    .map(
      (p) => `
    <li data-name="${p.name}">
      <span>${p.name}</span>
      <span class="sd-region">${p.region}</span>
    </li>`
    )
    .join("");
  searchResults.classList.toggle("open", hits.length > 0);
});

searchResults.addEventListener("click", (e) => {
  const li = e.target.closest("li");
  if (!li) return;

  const name = li.dataset.name;
  const p = PLANETS.find((x) => x.name === name);
  if (!p) return;

  flyTo(p);
  searchInput.value = p.name;
  searchResults.classList.remove("open");
});

document.addEventListener("click", (e) => {
  if (!e.target.closest(".search-wrap")) searchResults.classList.remove("open");
});

function flyTo(p) {
  const vr = viewport.getBoundingClientRect();
  const targetScale = Math.max(state.scale, 3);
  const px = p.x * img.naturalWidth;
  const py = p.y * img.naturalHeight;

  state.scale = targetScale;
  state.x = vr.width / 2 - px * targetScale;
  state.y = vr.height / 2 - py * targetScale;
  applyTransform();

  const pinEl = pinLayer.querySelector(`[data-name="${p.name}"]`);
  if (pinEl) selectPlanet(p, pinEl);
}

// Init
if (img.complete && img.naturalWidth) {
  buildPins();
  fitToViewport();
} else {
  img.addEventListener("load", () => {
    buildPins();
    fitToViewport();
  });
}

window.addEventListener("resize", fitToViewport);
